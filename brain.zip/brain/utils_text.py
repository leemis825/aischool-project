# -*- coding: utf-8 -*-
"""
brain.utils_text

이 모듈은 민원 엔진에서 공통으로 사용하는 텍스트 유틸을 모아둔 파일입니다.

- 위험/안전 관련 키워드 패턴 (CRITICAL_PATTERNS)
- 텍스트 정규화 맵 (NORMALIZE_MAP)
- normalize(text): 텍스트 정규화
- is_critical(text): 긴급 위험도 키워드 포함 여부 판단
- extract_keywords(text): 키워드 리스트 추출
- split_additional_location(text): '추가 위치 정보' 접미부 분리

프론트/다른 백엔드 코드에서는 보통 직접 호출하기보다는
minwon_engine.run_pipeline_once 안에서 간접적으로 사용됩니다.
"""

import re
from typing import List, Tuple

# -------------------- 위험 키워드 / 정규화 --------------------
CRITICAL_PATTERNS = [
    r"쓰러지", r"넘어가", r"붕괴", r"무너졌",
    r"전선", r"감전", r"불 ?났", r"화재", r"폭발",
    r"피가", r"폭행", r"위협", r"자살", r"죽고 싶"
]

NORMALIZE_MAP = {
    "전봇대": "전주",
    "길바닥": "도로",
    "차도": "도로",
    "보도블럭": "보도블록",
    "쓰러진 나무": "가로수 쓰러짐",
    "나무가 쓰러져": "가로수 쓰러짐",
}


# -------------------- 공통 유틸 --------------------
def normalize(text: str) -> str:
    t = text.strip()
    for k, v in NORMALIZE_MAP.items():
        t = t.replace(k, v)
    return t


def is_critical(text: str) -> bool:
    t = normalize(text)
    for pat in CRITICAL_PATTERNS:
        if re.search(pat, t):
            return True
    return False


def extract_keywords(text: str, max_k: int = 5) -> List[str]:
    tokens = re.split(r"[,\s\.]+", text)
    tokens = [w for w in tokens if len(w) >= 2]
    uniq = []
    for w in tokens:
        if w not in uniq:
            uniq.append(w)
    return uniq[:max_k]


def split_additional_location(text: str) -> Tuple[str, str]:
    """
    '... 추가 위치 정보: ...' 패턴이 있으면
    앞부분(사건)과 뒷부분(위치 후보)을 나눠준다.
    없으면 (원문, "") 그대로 반환.
    """
    # "추가 위치 정보:" / "추가위치정보:" 등 공백·콜론 변형까지 허용
    parts = re.split(r"추가\s*위치\s*정보\s*[:：]\s*", text, maxsplit=1)
    if len(parts) == 2:
        main, loc = parts[0].strip(), parts[1].strip()
        return main, loc

    return text.strip(), ""
