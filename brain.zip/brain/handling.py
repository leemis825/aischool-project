# -*- coding: utf-8 -*-
"""
brain.handling

민원을 어떻게 처리할지(단순 안내 / 전화 연결 / 공식 민원 접수)를
결정하는 로직과 "추가 질문(clarification)이 필요한 상황"을 관리하는 모듈입니다.

주요 기능:
- decide_handling_from_struct(category, needs_visit, risk_level, text):
    simple_guide / contact_only / official_ticket 중 어떤 처리 방식이 맞는지,
    전화 연결/공식 접수 필요 여부 플래그를 결정.

- need_clarification(summary_data, category, text):
    위치/시간 정보가 부족한데 출동이 필요해 보이는 경우
    한 번 더 위치를 물어볼지 여부 판단.

- build_clarification_response(...):
    추가 위치 정보를 요청하는 user_facing / staff_payload 구조를 만들어
    stage="clarification" 결과로 반환.

민원 엔진의 "처리 전략"에 해당하는 계층입니다.
"""
