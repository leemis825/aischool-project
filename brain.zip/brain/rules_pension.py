# -*- coding: utf-8 -*-
"""
brain.rules_pension

이 모듈은 연금/복지 관련 규칙과 안내 문구 생성을 담당합니다.

- PENSION_RULES: 출생연도별 노령/조기노령 연금 개시 연령 테이블
- compute_pension_age(birth_year, kind): 개시 연령 계산
- build_pension_message(text): '○○년생은 만 몇 세부터 수령 가능' 안내 문구 생성

민원 본문 중 '19xx년생' 패턴을 찾아 연금 나이를 계산할 때 사용되며,
minwon_engine.build_user_facing 에서 추가 안내 문구로 활용됩니다.
"""

import re

# -------------------- 국민연금 출생연도별 지급 개시 연령 --------------------
PENSION_RULES = [
    {"start": 1953, "end": 1956, "old_age": 61, "early": 56},
    {"start": 1957, "end": 1960, "old_age": 62, "early": 57},
    {"start": 1961, "end": 1964, "old_age": 63, "early": 58},
    {"start": 1965, "end": 1968, "old_age": 64, "early": 59},
    {"start": 1969, "end": 9999, "old_age": 65, "early": 60},
]


def compute_pension_age(birth_year: int, kind: str = "old") -> int:
    """출생연도에 따른 노령/조기노령 개시연령 반환."""
    for row in PENSION_RULES:
        if row["start"] <= birth_year <= row["end"]:
            return row["old_age"] if kind == "old" else row["early"]
    return 65


# -------------------- 국민연금 안내 문구 --------------------
def build_pension_message(text: str) -> str:
    m = re.search(r"(19[5-9]\d)년생", text)
    birth_year = None
    if m:
        birth_year = int(m.group(1))

    if birth_year:
        old_age = compute_pension_age(birth_year, "old")
        early_age = compute_pension_age(birth_year, "early")
        return (
            f"{birth_year}년생의 경우 노령연금은 만 {old_age}세, "
            f"조기노령연금은 만 {early_age}세부터 가능합니다."
        )
    return ""
