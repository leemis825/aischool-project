# -*- coding: utf-8 -*-
"""
brain.summarizer

민원 원문을 "짧게 잘 요약"하는 기능을 담당하는 모듈입니다.

주요 기능:
- build_fallback_summary(text, category):
    LLM이 실패했을 때 사용할 단순 요약 문자열 생성.
- summarize_for_user(text, category):
    주민에게 들려줄 한 줄 요약(Answer Core)을 생성.
- summarize_for_staff(text, category):
    담당 공무원이 빠르게 파악할 수 있는 3줄 요약, 위치, 시간 정보,
    현장 방문 필요 여부 등을 JSON 형식으로 반환.

minwon_engine.run_pipeline_once 에서
user_facing.answer_core / staff_payload.summary 등을 만들 때 사용됩니다.
"""
