# -*- coding: utf-8 -*-
"""
brain.classifier

민원 문장을 어떤 카테고리로 볼지, 현장 출동이 필요한 상황인지 등을
"분류"하는 로직만 따로 모아둔 모듈입니다.

주요 기능:
- detect_scenario_override(text):
    데모/테스트용 특정 시나리오(예: 쓰러진 나무, 1999년생 연금, 심리지원)를
    강제로 원하는 결과로 고정하는 규칙 레이어.
- rule_first_classify(text):
    키워드 기반 1차 카테고리 분류 (도로/시설물/연금·복지/심리지원/생활민원/기타).
- llm_classify_category_and_fieldwork(text, base_category):
    LLM을 통해 카테고리/현장 방문 필요 여부(needs_visit)/위험도(risk_level)를 보정.

이 모듈은 minwon_engine.run_pipeline_once 내에서 호출되며,
프론트에서 직접 사용할 일은 거의 없습니다.
"""
